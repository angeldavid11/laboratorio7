
const express = require('express');

// Definimos App
const App = express()

// Definimos algunas variables 


const port = process.env.PORT || 3000



const options = {
    root: __dirname
};


// Definimos funciones para llamarlas por el router
function getHTML(req, res) {


    res.sendFile('./index.html', options, (err) => {
        if (err) throw err;
        console.log('Sirviendo index.html')
    })
};

//Ruta
App.get('/', getHTML);

//puerto de Express


App.listen(port, () => {
    console.log('Aplicacion escuchando en el puerto: ' + port)
});